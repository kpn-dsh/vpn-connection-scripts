#!/bin/bash
set -m

function sed_home() {
    echo $(echo $HOME | sed 's_/_\\/_g')
}


function template_vpn_conf() {
cat << EOF
client
ca #_HOME_#/.vpn/#_TENANT_#/#_ENVIRONMENT_#/ca.crt
dev tun
proto tcp-client
remote 127.0.0.1 1195
nobind
cipher AES-256-CBC
auth-user-pass #_HOME_#/.vpn/#_TENANT_#/#_ENVIRONMENT_#/credentials
script-security 3
verb 3
up #_HOME_#/.vpn/initconfig.sh
down #_HOME_#/.vpn/cleanupvpnconfig.sh
EOF
}


function template_stunnel_conf() {
cat << EOF
# https://charlesreid1.com/wiki/OpenVPN/Stunnel
# https://www.stunnel.org/static/stunnel.html
client  = yes
debug = 7
pid = #_HOME_#/.vpn/#_TENANT_#/#_ENVIRONMENT_#/stunnel.pid
output = #_HOME_#/.vpn/#_TENANT_#/#_ENVIRONMENT_#/stunnel.log
[openvpn]
Options = all
Options = NO_SSLv3
Options = NO_SSLv3
options = NO_TLSv1
options = NO_TLSv1.1
verify = 0
verifyPeer = no
verifyChain = no
CAfile = #_HOME_#/.vpn/#_TENANT_#/#_ENVIRONMENT_#/ca.crt
sni = #_TENANT_#-openvpn.#_ENVIRONMENT_#.#_DNS_SUFFIX_#
connect = #_TENANT_#-openvpn.#_ENVIRONMENT_#.#_DNS_SUFFIX_#:1194
accept  = 127.0.0.1:1195
EOF
}


function help() {
cat << EOF
dsh-vpn.sh,  Version 1.0.0

dsh-vpn.sh init
  First command to execute (once) before other functionality becomes available. Initialize your system to use dsh-vpn.
  This will create a ~/.vpn folder for its content and append a line to the ~/.bashrc or ~/.bash_profile file.
  If openVPN is not installed yet, an attempt to apt-install it will be made.

dsh-vpn.sh clean <tenant> <environment>
    Clean up a tenant local configuration

dsh-vpn.sh create <tenant> <environment> <dns-suffix>
dsh-vpn.sh create
  Add a new VPN configuration to your system. If tenant and environment are not provided as arguments, they will be requested interactively.
  You will also need to provide the username and password for the VPN. These can be found on the configuration tab of the VPN container in DCOS.

dsh-vpn.sh connect <tenant> <environment>
  Connect using openVPN to the given tenant in the given environment. This will also run the getjks logic to obtain a Kafka config.
  Any shell opened after this one will export these Kafka config environment variables, making them available to the session.

dsh-vpn.sh update-ca <tenant> <environment> <dns-suffix>
dsh-vpn.sh update-ca
  Re-downloads the CA for an environment

dsh-vpn.sh diconnect
  Kill stunnel

dsh-vpn.sh purge
  Purge the whole ~/.vpn configuration directory
EOF
}


function provide_openvpn() {
    openvpn &> /dev/null
    if [ "$?" == "127" ]; then
        echo "OpenVPN not installed yet. Installing now. (trying sudo)"
        sudo apt install openvpn
    fi
}

function update_bash_file() {
    BASH_FILE=$1
    touch ${HOME}/.vpn/kafka_env
    LINE_PRESENT=`grep "source ${HOME}/.vpn/kafka_env" ${BASH_FILE}|wc -l`
    if [ "${LINE_PRESENT}" == "0" ];then
        echo "Appending sourcing lines to ${BASH_FILE}."
        echo "" >> ${BASH_FILE}
        echo "# SOURCING VPN Kafka Env variables" >> ${BASH_FILE}
        echo "source ${HOME}/.vpn/kafka_env" >> ${BASH_FILE}
    fi
}


function init() {
    if [ -d ${HOME}/.vpn/${TENANT}/${ENVIRONMENT} ]; then
        echo "DSH VPN has already been initiated. Not initiating (if needed use 'clean' or 'purge')."
        exit 1
    fi

    provide_openvpn

    # Assume the current directory has the latest *Client* DSH VPN code
    rm -rf /tmp/dsh-tool-vpn
    cp -rf ./ /tmp/dsh-tool-vpn

    mkdir -p ${HOME}/.vpn

    if [ -f ${HOME}/.bashrc ]; then
        update_bash_file "${HOME}/.bashrc"
    elif [ -f ${HOME}/.bash_profile ]; then
        update_bash_file "${HOME}/.bash_profile"
    else
        echo "No bashrc or bash_profile found. To have VPN Kafka Env variables in new terminals, execute:"
        echo "source ${HOME}/.vpn/kafka_env"
    fi

    cp /tmp/dsh-tool-vpn/initconfig.sh ${HOME}/.vpn/
    cp /tmp/dsh-tool-vpn/cleanupvpnconfig.sh ${HOME}/.vpn/
    cp /tmp/dsh-tool-vpn/getjks.sh ${HOME}/.vpn/getjks.sh

    chmod +x ${HOME}/.vpn/*.sh
    template_vpn_conf|sed "s/#_HOME_#/`sed_home`/g" > ${HOME}/.vpn/client.conf.template
    template_stunnel_conf|sed "s/#_HOME_#/`sed_home`/g" > ${HOME}/.vpn/stunnel.conf.template

    chmod -R 700 ~/.vpn

    rm -rf /tmp/dsh-tool-vpn
}

function create() {
    if [ "$#" == "0" ]; then
        read -p "Tenant": TENANT
        read -p "Environment": ENVIRONMENT
        read -p "DNS suffix": DNS_SUFFIX
    elif [ "$#" == "3" ]; then
        TENANT="$1"
        ENVIRONMENT="$2"
        DNS_SUFFIX="$3"
    else
        echo "Create expects 0 or 3 (tenant, environment, DNS suffix) parameters."
        exit 1
    fi

    if [ -d ${HOME}/.vpn/${TENANT}/${ENVIRONMENT} ]; then
        echo "Configuration yet for ${TENANT} ${ENVIRONMENT} for already exists. Not creating."
        exit 1
    fi

    read -p "Username [admin]": USERNAME
    read -s -p "Password": PASSWORD
    echo ""

    if [ "${USERNAME}" == "" ]; then
        USERNAME="admin"
    fi

    mkdir -p ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}
    wget https://${TENANT}-ca.${ENVIRONMENT}.${DNS_SUFFIX} -O ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/ca.crt
    template_vpn_conf|sed -e "s/#_USERNAME_#/$USERNAME/g"\
                      -e"s/#_HOME_#/`sed_home`/g"\
                      -e "s/#_TENANT_#/$TENANT/g"\
                      -e "s/#_ENVIRONMENT_#/$ENVIRONMENT/g"\
                      -e "s/#_DNS_SUFFIX_#/$DNS_SUFFIX/g" > ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/client.conf
    template_stunnel_conf|sed -e "s/#_USERNAME_#/$USERNAME/g"\
                      -e"s/#_HOME_#/`sed_home`/g"\
                      -e "s/#_TENANT_#/$TENANT/g"\
                      -e "s/#_ENVIRONMENT_#/$ENVIRONMENT/g"\
                      -e "s/#_DNS_SUFFIX_#/$DNS_SUFFIX/g" > ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/stunnel.conf
    printf "${USERNAME}\n${PASSWORD}" > ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/credentials

    mkdir ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/kafka
    #sed "s/^CONFIG_DIR=.*/CONFIG_DIR=`sed_home`\/.vpn\/${TENANT}\/${ENVIRONMENT}\/kafka/g" ${HOME}/.vpn/getjks.sh > ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/kafka/getjks.sh

    chmod -R 700 ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/*
}


function clean() {
    if [ "$#" == "0" ]; then
        read -p "Tenant": TENANT
        read -p "Environment": ENVIRONMENT
    elif [ "$#" == "2" ]; then
        TENANT="$1"
        ENVIRONMENT="$2"
    else
        echo "Create expects 0 or 3 (tenant, environment, platform domain) parameters."
        exit 1
    fi

    if [ ! -d ${HOME}/.vpn/${TENANT}/${ENVIRONMENT} ]; then
        echo "Configuration yet for ${TENANT} ${ENVIRONMENT} for does not exists. Not cleaning."
        exit 1
    fi

    rm -rf ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/
}

function purge() {
    read -p "Are you sure you want to remove completely your ~/.vpn directory? " -n 1 -r
    echo    # (optional) move to a new line
    if [[ ! $REPLY =~ ^[Yy]$ ]]
    then
        [[ "$0" = "$BASH_SOURCE" ]] && exit 1 || return 1 # handle exits from shell or function but don't exit interactive shell
    fi
    rm -rf ${HOME}/.vpn/
}

function connect() {
    if [ "$#" != 2 ]; then
        echo "Connect expects 2 (tenant, environment) parameters."
        exit 1
    fi

    TENANT=$1
    ENVIRONMENT=$2

    if [ ! -d ${HOME}/.vpn/${TENANT}/${ENVIRONMENT} ]; then
        echo "No configuration yet for ${TENANT} ${ENVIRONMENT}: could not find '${HOME}/.vpn/${TENANT}/${ENVIRONMENT}'"
        echo "Create it first with the create command, using ${TENANT} and ${ENVIRONMENT} as arguments."
        exit 1
    fi

    if [ "$EUID" != "0" ]; then
        echo "stunnel requires root permissions. (trying sudo)"
        sudo stunnel ~/.vpn/${TENANT}/${ENVIRONMENT}/stunnel.conf &
    else
        stunnel ~/.vpn/${TENANT}/${ENVIRONMENT}/stunnel.conf &
    fi

    if [ "$EUID" != "0" ]; then
        echo "OpenVPN requires root permissions. (trying sudo)"
        sudo openvpn ~/.vpn/${TENANT}/${ENVIRONMENT}/client.conf &
    else
        openvpn ~/.vpn/${TENANT}/${ENVIRONMENT}/client.conf &
    fi

    BGID=`jobs|grep "dsh-vpn.sh connect ${TENANT} ${ENVIRONMENT}"|sed -r 's/^\[([0-9]+)\].*$/\1/'`
    sleep 3

    sudo mkdir -p /tmp/kafka/config
    sudo chown -R ${USER}:${USER} /tmp/kafka
    sudo chmod -R 700  /tmp/kafka
    ${HOME}/.vpn/getjks.sh ${TENANT}
    echo "Writing config to env variables and ${HOME}/.vpn/kafka_env"
    cp -r /tmp/kafka/config/* ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/kafka/
    sed 's/^/export /' ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/kafka/kafkasec.properties > ${HOME}/.vpn/kafka_env

    fg ${BGID}
}


function update_ca() {
    if [ "$#" == "0" ]; then
        read -p "Tenant": TENANT
        read -p "Environment": ENVIRONMENT
        read -p "DNS suffix": DNS_SUFFIX
    elif [ "$#" == "3" ]; then
        TENANT="$1"
        ENVIRONMENT="$2"
        DNS_SUFFIX="$3"
    else
        echo "Create expects 0 or 3 (tenant, environment, DNS suffix) parameters."
        exit 1
    fi

    mkdir -p ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}
    wget https://${TENANT}-ca.${ENVIRONMENT}.${DNS_SUFFIX} -O ${HOME}/.vpn/${TENANT}/${ENVIRONMENT}/ca.crt
}

function disconnect() {
    sudo pkill -9 openvpn
    sudo pkill -9 stunnel
}

if [ "$1" == "init" ]; then
    init "${@:2}"
elif [ "$1" == "create" ]; then
    create "${@:2}"
elif [ "$1" == "connect" ]; then
    connect "${@:2}"
elif [ "$1" == "disconnect" ]; then
    disconnect
elif [ "$1" == "clean" ]; then
    clean "${@:2}"
elif [ "$1" == "help" ]; then
    help
elif [ "$1" == "purge" ]; then
    purge
elif [ "$1" == "update-ca" ]; then
    update_ca "${@:2}"
else
    echo "Unknown Command. Known Commands: init, create, connect, clean, purge, update-ca, help"
    exit 1
fi
