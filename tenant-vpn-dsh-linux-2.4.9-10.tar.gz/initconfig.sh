#!/bin/bash
CONFIG_DIR=/tmp/kafka/config
conffile=$CONFIG_DIR/kafkasec.properties
  
write_kafka_secconf_to_file() {
  if [ ! -z $OPENVPN_KAFKA_SSL_TRUSTSTORE_PASSWORD ] ; then
    echo "writing Kafka security configuration to $conffile"
    echo "KAFKA_SECURITY_PROTOCOL=$(echo $OPENVPN_KAFKA_SECURITY_PROTOCOL)" >> "$conffile"
    echo "KAFKA_SSL_TRUSTSTORE_PASSWORD=$(echo $OPENVPN_KAFKA_SSL_TRUSTSTORE_PASSWORD)" >> "$conffile"
    echo "KAFKA_SSL_KEYSTORE_PASSWORD=$(echo $OPENVPN_KAFKA_SSL_KEYSTORE_PASSWORD)" >> "$conffile"
    echo "KAFKA_SSL_KEY_PASSWORD=$(echo $OPENVPN_KAFKA_SSL_KEY_PASSWORD)" >> "$conffile"
    echo "KAFKA_GROUP_ID=$(echo $OPENVPN_KAFKA_GROUP_ID)" >> "$conffile"
  fi
}

#Set DNS configuration based on the OS
OS=`uname`
if [ "$OS" = "Darwin" ] ; then
    echo "configuring DNS for OSX"
    # search the current network service and select the first output line (network service name)
    CURRENT_NETWORK_SERVICE=`./osx_currentnetworkservice.sh | sed -n 1p`
    echo "configuring DNS for network service $CURRENT_NETWORK_SERVICE"
    # add DC/OS DNS entry to current DNS entries as the first entry
    DNS_ENTRIES=`/usr/sbin/networksetup -getdnsservers $CURRENT_NETWORK_SERVICE`
    if [[ "$DNS_ENTRIES" == "There aren't any DNS Servers set"* ]] ; then
      NEW_DNS_ENTRIES="198.51.100.1"
    else
      NEW_DNS_ENTRIES=`echo $DNS_ENTRIES | tr '\n' ' ' | sed -e 's/^/198.51.100.1 /'`
    fi
    /usr/sbin/networksetup -setdnsservers $CURRENT_NETWORK_SERVICE $NEW_DNS_ENTRIES
else
    echo "configuring DNS for Linux"
    echo "configuring DNS in /etc/resolv.conf"
    sed -i '/nameserver/ i\nameserver 198.51.100.1' /etc/resolv.conf
fi

mkdir -p $CONFIG_DIR
write_kafka_secconf_to_file
