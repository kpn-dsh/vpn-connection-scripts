<#
.SYNOPSIS
  Connect to DSH VPN over Stunnel TCP connection.
.Description
  This script helps you manage connecting to your DSH tenant's VPN server by modifying the stunnel config automatically

  ASSUMPTIONS AND WARNINGS:
  ==============================

  - Must: run in a 64 bit Windows OS
  - Must: run in an elevated PowerShell prompt

  - Assumes: Stunnel is installed to ${env:ProgramFiles(x86)}\stunnel
  - Assumes: OpenVPN is installed to ${env:ProgramFiles}\OpenVPN\

  - Note: you may have to allow `Set-ExecutionPolicy ByPass`, which can be undone using `Set-ExecutionPolicy Restricted`, see https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.securit
  - Note: this does not set the env vars as the linux script does

  - Tested: on Windows 10 - 18/Aug/2020 using openvpn and stunnel installed as `choco install openvpn -y` & `choco install stunnel -y`

.EXAMPLE
  ./dsh-vpn.ps1 help"
#>

#---------------------------------------------------------[Parameters]--------------------------------------------------------

param (
    [string]$command = "",
    [parameter( ValueFromRemainingArguments = $true, ValueFromPipeline = $false )]
    [object]$invalidArgs = ""
)

#---------------------------------------------------------[Config]--------------------------------------------------------
$ErrorActionPreference = "Stop"

$prog_version = "1.0.1"

# This is the default path for OpenVPN executable.
$OVPNExePath = "${env:ProgramFiles}\OpenVPN\bin\openvpn-gui.exe"
$StunnelExePath = ""

#-----------------------------------------------------------[Functions]------------------------------------------------------------
function Version {
    param ( [string]$prog_version )
    Write-Host "dsh-vpn.ps1 version: ${prog_version}"
    Exit 0
}

function Help {
    param ( [string]$message_error = "" )
    if ( $message_error -ne "" ) {
        Write-Host
        Write-Host "Error:`t" -ForegroundColor Red -NoNewline
        Write-Host $message_error
    }
    Write-Host
    Write-Host "dsh-vpn.ps1, version: ${prog_version}"
    Write-Host "Set up VPN for a DSH cluster"
    Write-Host
    Write-Host "dsh-vpn.ps1 clean"
    Write-Host "    Clean up a tenant local configuration"
    Write-Host
    Write-Host "dsh-vpn.ps1 create"
    Write-Host "  Add a new VPN configuration to your system. If tenant and environment are not provided as arguments, they will be requested interactively."
    Write-Host "  You will also need to provide the username and password for the VPN. These can be found on the configuration tab of the VPN container in DCOS."
    Write-Host
    Write-Host "dsh-vpn.ps1 connect"
    Write-Host "  Connect using openVPN to the given tenant in the given environment. This will also run the getjks logic to obtain a Kafka config."
    Write-Host "  Any shell opened after this one will export these Kafka config environment variables, making them available to the session."
    Write-Host
    Write-Host "dsh-vpn.ps1 disconnect"
    Write-Host "  Terminate stunnel and openvpn connections."
    Write-Host
    Write-Host "dsh-vpn.ps1 purge"
    Write-Host "  Purge the whole ~\.vpn configuration directory"
    Write-Host
    Write-Host "dsh-vpn.ps1 logs"
    Write-Host "  Open the logs directory"
    Write-Host
    Write-Host "dsh-vpn.ps1 config"
    Write-Host "  Open the config directory"
    Write-Host
    Write-Host "dsh-vpn.ps1 update-ca"
    Write-Host "  Update the client CA"
    Write-Host
    Write-Host "dsh-vpn.ps1 help"
    Write-Host "  Display help"

    Exit 1
}

# Check If too many arguments were passed on the command line or piped
if ( $invalidArgs -ne "" ) {
    if ( $invalidArgs -eq "/?" ) {
        Help
    }
    Else {
        Help "Invalid or too many command line argument(s)"
    }
}

function Init() {
    New-Item -ItemType Directory -Force -Path $env:USERPROFILE\.vpn\
    # Assume the current directory has the latest *Client* DSH VPN code
}


function Update-CA {
    param (
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the tenant name:" )][string]$tenant,
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the environment name:" )][string]$environment,
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the dns suffix for the platform:" )][string]$dns_suffix
    )
    Write-CA -tenant $tenant -environment $environment -dns_suffix $dns_suffix
}

function Write-CA {
    param ([string]$tenant, [string]$environment, [string]$dns_suffix)
    $url = "https://$tenant-ca.$environment.$dns_suffix"
    $output = "$env:USERPROFILE\.vpn\$tenant\$environment\ca.crt"
    # Invoke-WebRequest -Uri $url -OutFile $output
    (New-Object System.Net.WebClient).DownloadFile($url, $output)
}

function Write-VPN-Conf {
    param ([string]$tenant, [string]$environment)

    $config_file = "$env:USERPROFILE\.vpn\$tenant\$environment\client.ovpn"
    # the identation bellow is correct (no spaces in front of text) - leave it as is
    $configuration = @"
client
ca $env:USERPROFILE\.vpn\$tenant\$environment\ca.crt
dev tun
proto tcp-client
remote 127.0.0.1 1195
nobind
cipher AES-256-CBC
auth-user-pass $env:USERPROFILE\.vpn\$tenant\$environment\credentials.cred
script-security 3
verb 3
dhcp-option DNS $env:DNS_CLUSTER_IP
# register-dns
# block-outside-dns
up "$env:USERPROFILE\.vpn\$tenant\$environment\client_up.bat"
# down "$env:USERPROFILE\.vpn\$tenant\$environment\cleanupvpnconfig.sh"
"@
    Set-Content $config_file $configuration.replace("\", "\\")
}


function Write-VPN-UP {
    param ([string]$tenant, [string]$environment)

    $config_file = "$env:USERPROFILE\.vpn\$tenant\$environment\client_up.bat"
    # the identation bellow is correct (no spaces in front of text) - leave it as is
    $configuration = @"
@echo off
SET kafka_file="%USERPROFILE%\.vpn\${tenant}\${environment}\kafkasec.properties"
if defined OPENVPN_KAFKA_SSL_TRUSTSTORE_PASSWORD (
        echo "Writing Kafka security configuration to %kafka_file%"
        echo KAFKA_SECURITY_PROTOCOL=%OPENVPN_KAFKA_SECURITY_PROTOCOL% > %kafka_file%
        echo KAFKA_SSL_TRUSTSTORE_PASSWORD=%OPENVPN_KAFKA_SSL_TRUSTSTORE_PASSWORD% >> %kafka_file%
        echo KAFKA_SSL_KEYSTORE_PASSWORD=%OPENVPN_KAFKA_SSL_KEYSTORE_PASSWORD% >> %kafka_file%
        echo KAFKA_SSL_KEY_PASSWORD=%OPENVPN_KAFKA_SSL_KEY_PASSWORD% >> %kafka_file%
        echo KAFKA_GROUP_ID=%OPENVPN_KAFKA_GROUP_ID% >> %kafka_file%
    ) else (
        echo "skipping kafka file, could not find env vars"
    )
EXIT /b 0
"@
    Set-Content $config_file $configuration
}


function Write-Stunnel-Conf {
    param ([string]$tenant, [string]$environment, [string]$dns_suffix)

    $config_file = "$env:USERPROFILE\.vpn\$tenant\$environment\stunnel.conf"

    Set-Content $config_file "# Auto generated file by 'dsh-vpn.ps1'"
    Add-Content $config_file "# https://charlesreid1.com/wiki/OpenVPN/Stunnel"
    Add-Content $config_file "# https://www.stunnel.org/static/stunnel.html"
    Add-Content $config_file "client = yes"
    Add-Content $config_file "debug = 7"
    Add-Content $config_file "output = $env:USERPROFILE\.vpn\$tenant\$environment\logs\stunnel.log"
    Add-Content $config_file "[openvpn]"
    Add-Content $config_file "Options = all"
    Add-Content $config_file "Options = NO_SSLv3"
    Add-Content $config_file "Options = NO_SSLv3"
    Add-Content $config_file "options = NO_TLSv1"
    Add-Content $config_file "options = NO_TLSv1.1"
    Add-Content $config_file "verify = 0"
    Add-Content $config_file "verifyPeer = no"
    Add-Content $config_file "verifyChain = no"
    Add-Content $config_file "CAfile = $env:USERPROFILE\.vpn\$tenant\$environment\ca.crt"
    Add-Content $config_file "sni = $tenant-openvpn.$environment.$dns_suffix"
    Add-Content $config_file "connect = ${tenant}-openvpn.${environment}.${dns_suffix}:1194"
    Add-Content $config_file "accept = 127.0.0.1:1195"
}

function Logs {
    param (
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the tenant name:" )][string]$tenant,
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the environment name:" )][string]$environment
    )
    $LogsDir = "$env:USERPROFILE\.vpn\$tenant\$environment\logs\"
    Invoke-Item $LogsDir
}

function Config {
    param (
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the tenant name:" )][string]$tenant,
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the environment name:" )][string]$environment
    )
    $ConfigDir = "$env:USERPROFILE\.vpn\$tenant\$environment\"
    Invoke-Item $ConfigDir
}

function Create {
    param (
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the tenant name:" )][string]$tenant,
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the environment name:" )][string]$environment,
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the dns suffix for the platform:" )][string]$dns_suffix,
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the openvpn username[admin]:" )][string]$openvpn_username,
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the openvpn password:" )][SecureString]$openvpn_password
    )
    If (Test-Path $env:USERPROFILE\.vpn\$tenant\$environment -PathType Container) {
        Write-Host "Configuration yet for -tenant $tenant -environment $environment for already exists. Not creating."
        Exit 1
    }
    if ($openvpn_username -eq "") {
        $openvpn_username = "admin"
    }

    Init

    New-Item -ItemType Directory -Force -Path $env:USERPROFILE\.vpn\$tenant\$environment\logs\
    # Write the configurations
    Write-CA -tenant $tenant -environment $environment -dns_suffix $dns_suffix
    Write-Stunnel-Conf -tenant $tenant -environment $environment $dns_suffix
    Write-VPN-Conf -tenant $tenant -environment $environment
    Write-VPN-UP -tenant $tenant -environment $environment
    # Write the username and password to disk
    $openvpn_password_insecure = [System.Net.NetworkCredential]::new("", $openvpn_password).Password
    Set-Content "$env:USERPROFILE\.vpn\$tenant\$environment\credentials.cred" "${openvpn_username}`n${openvpn_password_insecure}"
}

function Clean {
    param (
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the tenant name:" )][string]$tenant,
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the environment name:" )][string]$environment
    )
    If (-not (Test-Path $env:USERPROFILE\.vpn\$tenant\$environment -PathType Container)) {
        Write-Host "Configuration yet for -tenant $tenant -environment $environment for does not exists. Not cleaning."
        Exit 1
    }
    Remove-Item -path $env:USERPROFILE\.vpn\$tenant\$environment\ -recurse
}

function Purge {
    $title = "Purging the $env:USERPROFILE\.vpn\ directory"
    $question = 'Are you sure you want to proceed?'
    $choices = '&Yes', '&No'
    $decision = $Host.UI.PromptForChoice($title, $question, $choices, 1)

    if ($decision -eq 0) {
        Remove-Item -path $env:USERPROFILE\.vpn\ -recurse
    }
    else {
        Write-Host 'cancelled'
    }
}

function Stop-Stunnel {
    $job = Start-Job -Name "stunnel-dsh-client-stop" -ScriptBlock { & $args[0] -stop } -ArgumentList @($StunnelExePath)
    Wait-Job $job | Out-Null
    Try { Stop-Service stunnel } Catch {}
    Try { Stop-Process -Name "stunnel" -Force 2> $null } Catch {}
}

function Start-Stunnel {
    param ([string]$tenant, [string]$environment)
    Assert-Tenant-Exists -tenant $tenant -environment $environment
    $stunnel_config = "$env:USERPROFILE\.vpn\$tenant\$environment\stunnel.conf"
    # WARNING: Unfortuanetely it appears that on Windows stunnel (version: 6.2) has issue parsing all the cli arguments and that the order matters
    # the config file based on the experiments conducted must stay first.
    # before changing the arguments please conduct experiments to ensure stunnel is not defaulting to the default config file
    # and document the stunnel version
    $job = Start-Job -Name "stunnel-dsh-client" -ScriptBlock { & $args[0] $args[1] } -ArgumentList @($StunnelExePath, $stunnel_config)    
    Wait-Job $job | Out-Null
}

function Restart-Stunnel {
    param ([string]$tenant, [string]$environment)
    Stop-Stunnel
    Start-Stunnel -tenant $tenant -environment $environment
}

function Start-OpenVPN {
    param ([string]$tenant, [string]$environment)
    # openvpn-gui has to be stopped
    Stop-OpenVPN

    # ARGS
    $OVPNConfigDir = "$env:USERPROFILE\.vpn\$tenant\$environment"
    $LogsDir = "$env:USERPROFILE\.vpn\$tenant\$environment\logs\"
    $job = Start-Job -Name "openvpn-dsh-client" -ScriptBlock { & $args[0] --connect "client.ovpn" --config_dir $args[1] --log_dir $args[2] } -ArgumentList @($OVPNExePath, $OVPNConfigDir, $LogsDir)
    Write-Host "Use 'Receive-Job $(${job}.Id)' to see the logs"
    Write-Host " or visit the logs directory '${LogsDir}'"
}

function Stop-OpenVPN {
    Try { Stop-Job -Name "openvpn-dsh-client" -Force 2> $null } Catch {}
    Try { Stop-Process -Name "openvpn-gui" -Force 2> $null } Catch {}
    Try { Stop-Process -Name "openvpn" -Force 2> $null } Catch {}
}

function Assert-Tenant-Exists {
    param (
        [string]$tenant,
        [string]$environment
    )
    If (-not (Test-Path $env:USERPROFILE\.vpn\$tenant\$environment -PathType Container)) {
        Write-Host "No configuration yet for -tenant $tenant -environment $environment."
        Write-Host "Create it first with the create command."
        Exit 1
    }
}

function Connect {
    param (
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the tenant name:" )][string]$tenant,
        [parameter( Mandatory = $true, ValueFromPipeline = $true, HelpMessage = "Enter the environment name:" )][string]$environment
    )

    If (-not (Test-path $OVPNExePath )) {
	    Write-Host "OpenVPN is not installed or not installed in default. Please (re-)install OpenVPN under $OVPNExePath "
        Exit 1
    }
    

    If (Test-path ${env:ProgramFiles(x86)}\stunnel\bin\stunnel.exe) {
        $StunnelExePath="${env:ProgramFiles(x86)}\stunnel\bin\stunnel.exe"
    }
    elseif (Test-path $env:LOCALAPPDATA\stunnel\bin\stunnel.exe) {
        $StunnelExePath="$env:LOCALAPPDATA\stunnel\bin\stunnel.exe"
    }
    else {    
        Write-Host "stunnel not installed (correctly). Please (re-)install stunnel for ALL users"
        Exit 1
    }

    Init

    Assert-Tenant-Exists -tenant $tenant -environment $environment

    Disconnect

    $regex = "(?<=$environment\.).*"
    #Write-Host "Dns suffix: regex $regex"
    $dns_suffix = Select-String -Path $env:USERPROFILE\.vpn\$tenant\$environment\stunnel.conf -Pattern $regex | %{$_.Matches}| %{$_.Value} | select-object -first 1
    Write-Host "Dns suffix: $dns_suffix"
    Write-CA -tenant $tenant -environment $environment -dns_suffix $dns_suffix
    Restart-Stunnel -tenant $tenant -environment $environment
    $job = Start-OpenVPN -tenant $tenant -environment $environment
    Write-Host $job
}

function Disconnect {
    Stop-OpenVPN
    Stop-Stunnel
}

#-----------------------------------------------------------[Main]------------------------------------------------------------
Try {
    If ( "$command" -eq "create" ) {
        Create
    }
    ElseIf ( "$command" -eq "connect" ) {
        Connect
    }
    ElseIf ( "$command" -eq "disconnect" ) {
        Disconnect
    }
    ElseIf ( "$command" -eq "clean" ) {
        Clean
    }
    ElseIf ( "$command" -eq "help" ) {
        Help
    }
    ElseIf ( "$command" -eq "purge" ) {
        Purge
    }
    ElseIf ( "$command" -eq "version" ) {
        Version -prog_version $prog_version
    }
    ElseIf ( "$command" -eq "logs" ) {
        Logs
    }
    ElseIf ( "$command" -eq "config" ) {
        Config
    }
    ElseIf ( "$command" -eq "update-ca" ) {
        Update-CA
    }
    Else {
        Write-Host "Unknown command '$command'. Known Commands: create, connect, disconnect, clean, purge, version, config, logs, update-ca, help"
        Exit 1
    }
}
Catch {
    " -" * 5 + " Caught an Error " + " -" * 5
    $Error[0] | Format-List * -Force
    Exit 1
}
